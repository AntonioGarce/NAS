Docker setup was originally created at https://github.com/cloudsriseup/gyoithon_dbautopwn .  The repository may be found @ https://hub.docker.com/r/projectnexus/summon5ai/
