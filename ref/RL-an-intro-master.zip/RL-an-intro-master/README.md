# RL an intro

This project is a collection of implementations of environments and agents from Reinforcement Learning: an Introduction.

## Current environments and agents

- stationary _k_-armed bandit environment
    - greedy agent
    - epsilon-greedy agent
