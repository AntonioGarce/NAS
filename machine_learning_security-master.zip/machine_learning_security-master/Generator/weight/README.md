weights of networks.
