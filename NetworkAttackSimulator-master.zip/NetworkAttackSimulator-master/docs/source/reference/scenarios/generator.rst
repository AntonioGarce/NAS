.. _scenario_generator:

Scenario Generator
===================

.. automodule:: nasim.scenarios.generator
   :members:
