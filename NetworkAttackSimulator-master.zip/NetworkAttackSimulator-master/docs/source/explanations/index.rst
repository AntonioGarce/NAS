.. _explanations:

Explanations
============

More technical explanations related to NASim.

.. toctree::
    :maxdepth: 1

    scenario_generation
