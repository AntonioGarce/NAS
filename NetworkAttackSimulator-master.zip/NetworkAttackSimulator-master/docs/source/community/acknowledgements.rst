.. _acknowledgements:

Acknowledgements
================

* Inspiration for the documentation was taken from the `DeeR <https://deer.readthedocs.io/en/master/>`_ project.
