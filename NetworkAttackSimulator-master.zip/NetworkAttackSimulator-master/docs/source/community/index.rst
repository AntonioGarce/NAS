.. _community:

Community & Development
=======================

.. toctree::
    :maxdepth: 1

    development
    license
    contact
    acknowledgements
    distributing
